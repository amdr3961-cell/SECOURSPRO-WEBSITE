import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { Formations } from "@/components/formations";
import { About } from "@/components/about";
import { Testimonials } from "@/components/testimonials";
import { Partners } from "@/components/partners";
import { Contact } from "@/components/contact";
import { CTA } from "@/components/cta";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Formations />
      <About />
      <Testimonials />
      <Partners />
      <CTA />
      <Contact />
      <Footer />
    </main>
  );
}

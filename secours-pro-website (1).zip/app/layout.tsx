import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
});

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
});

export const metadata: Metadata = {
  title: 'Secours Pro | Formation Premiers Secours au Maroc',
  description: 'Leader marocain de la formation aux premiers secours. Formations certifiantes PSC1, SST, DAE pour particuliers et entreprises. Plus de 15 000 personnes formées.',
  keywords: 'premiers secours, formation, PSC1, SST, DAE, secourisme, Maroc, Casablanca, Rabat, certification, entreprise',
  authors: [{ name: 'Secours Pro' }],
  openGraph: {
    title: 'Secours Pro | Formation Premiers Secours au Maroc',
    description: 'Apprenez les gestes qui sauvent des vies. Formations certifiantes en premiers secours.',
    type: 'website',
    locale: 'fr_MA',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#dc2626',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className="bg-background scroll-smooth">
      <body className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}

"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  Clock,
  Users,
  Award,
  ArrowLeft,
  Check,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Download,
  Share2,
  Heart,
  Shield,
  BookOpen,
  Target,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { formations, formatPrice, type Formation } from "@/lib/data";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

const levelColors = {
  Débutant: "bg-green-100 text-green-800",
  Intermédiaire: "bg-yellow-100 text-yellow-800",
  Avancé: "bg-orange-100 text-orange-800",
  Professionnel: "bg-primary/10 text-primary",
};

function FormationDetailContent({ formation }: { formation: Formation }) {
  const relatedFormations = formations
    .filter((f) => f.category === formation.category && f.id !== formation.id)
    .slice(0, 3);

  return (
    <>
      <Header />
      <main className="min-h-screen bg-background">
        {/* Breadcrumb */}
        <div className="bg-muted/50 py-4 border-b border-border">
          <div className="container mx-auto px-4">
            <nav className="flex items-center gap-2 text-sm text-muted-foreground">
              <Link href="/" className="hover:text-primary transition-colors">
                Accueil
              </Link>
              <ChevronRight className="h-4 w-4" />
              <Link
                href="/#formations"
                className="hover:text-primary transition-colors"
              >
                Formations
              </Link>
              <ChevronRight className="h-4 w-4" />
              <span className="text-foreground font-medium truncate max-w-[200px]">
                {formation.title}
              </span>
            </nav>
          </div>
        </div>

        {/* Hero Section */}
        <section className="relative">
          <div className="absolute inset-0 h-[400px] bg-gradient-to-b from-primary/5 to-transparent" />
          <div className="container mx-auto px-4 py-12 relative">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              {/* Left Column - Image */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                  <div className="aspect-[4/3] relative">
                    <Image
                      src={formation.image}
                      alt={formation.title}
                      fill
                      className="object-cover"
                      priority
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                    <Badge
                      className={`${levelColors[formation.level]} text-sm px-3 py-1`}
                    >
                      {formation.level}
                    </Badge>
                    {formation.certification && (
                      <Badge className="bg-card/90 text-foreground gap-1">
                        <Award className="h-4 w-4 text-primary" />
                        Formation Certifiante
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Video Section */}
                <div className="mt-6">
                  <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    Aperçu de la formation
                  </h3>
                  <div className="relative rounded-xl overflow-hidden bg-foreground/5 aspect-video">
                    <iframe
                      src="https://www.youtube.com/embed/cosVBV96E2g"
                      title="Formation Premiers Secours"
                      className="absolute inset-0 w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </div>
              </motion.div>

              {/* Right Column - Details */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="lg:sticky lg:top-24"
              >
                <Badge className="bg-primary/10 text-primary mb-4">
                  {formation.category}
                </Badge>

                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
                  {formation.title}
                </h1>

                <p className="text-lg text-muted-foreground mb-6">
                  {formation.longDescription}
                </p>

                {/* Quick Info Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                  <Card className="bg-muted/50 border-0">
                    <CardContent className="p-4 text-center">
                      <Clock className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="text-sm text-muted-foreground">Durée</div>
                      <div className="font-semibold text-foreground">
                        {formation.duration}
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/50 border-0">
                    <CardContent className="p-4 text-center">
                      <Users className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="text-sm text-muted-foreground">
                        Participants
                      </div>
                      <div className="font-semibold text-foreground">
                        Max {formation.maxParticipants}
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/50 border-0">
                    <CardContent className="p-4 text-center">
                      <Calendar className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="text-sm text-muted-foreground">
                        Prochaine
                      </div>
                      <div className="font-semibold text-foreground text-sm">
                        {formation.nextSession}
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/50 border-0">
                    <CardContent className="p-4 text-center">
                      <MapPin className="h-6 w-6 text-primary mx-auto mb-2" />
                      <div className="text-sm text-muted-foreground">Lieu</div>
                      <div className="font-semibold text-foreground">
                        Casablanca
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Price Card */}
                <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 mb-6">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">
                          Prix de la formation
                        </div>
                        <div className="text-4xl font-bold text-primary">
                          {formatPrice(formation.price)}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Par personne, supports inclus
                        </div>
                      </div>
                      {formation.popular && (
                        <Badge className="bg-primary text-primary-foreground">
                          Best-seller
                        </Badge>
                      )}
                    </div>

                    <Separator className="my-4" />

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center gap-2 text-sm text-foreground/80">
                        <Check className="h-4 w-4 text-primary" />
                        <span>Supports pédagogiques inclus</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-foreground/80">
                        <Check className="h-4 w-4 text-primary" />
                        <span>Attestation de formation</span>
                      </div>
                      {formation.certification && (
                        <div className="flex items-center gap-2 text-sm text-foreground/80">
                          <Check className="h-4 w-4 text-primary" />
                          <span>Certificat officiel délivré</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm text-foreground/80">
                        <Check className="h-4 w-4 text-primary" />
                        <span>Pause-café et déjeuner offerts</span>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button
                        size="lg"
                        className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                      >
                        <Calendar className="h-5 w-5 mr-2" />
                        Réserver maintenant
                      </Button>
                      <Button
                        size="lg"
                        variant="outline"
                        className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      >
                        <Phone className="h-5 w-5 mr-2" />
                        Nous appeler
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    <Download className="h-4 w-4 mr-2" />
                    Télécharger le programme
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    <Share2 className="h-4 w-4 mr-2" />
                    Partager
                  </Button>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Program Details */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-12">
                {/* Objectives */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <Target className="h-6 w-6 text-primary" />
                    Objectifs de la formation
                  </h2>
                  <Card>
                    <CardContent className="p-6">
                      <ul className="space-y-4">
                        {formation.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                              <Check className="h-4 w-4 text-primary" />
                            </div>
                            <span className="text-foreground/90 pt-1">
                              {feature}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Program */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <BookOpen className="h-6 w-6 text-primary" />
                    Programme détaillé
                  </h2>
                  <div className="space-y-4">
                    {[
                      {
                        title: "Module 1 : Introduction et fondamentaux",
                        duration: "1h30",
                        content:
                          "Présentation des objectifs, rôle du secouriste, cadre légal et réglementaire, protection et alerte.",
                      },
                      {
                        title: "Module 2 : Les gestes qui sauvent",
                        duration: "2h00",
                        content:
                          "Hémorragies, plaies, brûlures, traumatismes, positions d'attente et surveillance.",
                      },
                      {
                        title: "Module 3 : Arrêt cardiaque et RCP",
                        duration: "2h00",
                        content:
                          "Reconnaissance de l'arrêt cardiaque, massage cardiaque, ventilation artificielle, utilisation du DAE.",
                      },
                      {
                        title: "Module 4 : Mises en situation",
                        duration: "1h30",
                        content:
                          "Exercices pratiques, cas concrets, évaluation des acquis et remise des attestations.",
                      },
                    ].map((module, index) => (
                      <Card
                        key={index}
                        className="hover:border-primary/50 transition-colors"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <h3 className="font-semibold text-foreground">
                              {module.title}
                            </h3>
                            <Badge variant="outline">{module.duration}</Badge>
                          </div>
                          <p className="text-muted-foreground text-sm">
                            {module.content}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </motion.div>

                {/* Prerequisites */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-3">
                    <Shield className="h-6 w-6 text-primary" />
                    Prérequis et public cible
                  </h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="font-semibold text-foreground mb-4">
                          Prérequis
                        </h3>
                        <ul className="space-y-2 text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Aucun prérequis nécessaire
                          </li>
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Être en bonne condition physique
                          </li>
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Âge minimum : 16 ans
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="font-semibold text-foreground mb-4">
                          Public cible
                        </h3>
                        <ul className="space-y-2 text-muted-foreground">
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Salariés d&apos;entreprise
                          </li>
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Responsables sécurité
                          </li>
                          <li className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-primary" />
                            Grand public
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Contact Card */}
                <Card className="sticky top-24">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                      <Heart className="h-5 w-5 text-primary" />
                      Besoin d&apos;aide ?
                    </h3>
                    <p className="text-sm text-muted-foreground mb-6">
                      Notre équipe est disponible pour répondre à toutes vos
                      questions sur cette formation.
                    </p>
                    <div className="space-y-4">
                      <a
                        href="tel:+212522123456"
                        className="flex items-center gap-3 text-foreground/80 hover:text-primary transition-colors"
                      >
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Phone className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">
                            Téléphone
                          </div>
                          <div className="font-medium">+212 522 123 456</div>
                        </div>
                      </a>
                      <a
                        href="mailto:contact@secourspro.ma"
                        className="flex items-center gap-3 text-foreground/80 hover:text-primary transition-colors"
                      >
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Mail className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">
                            Email
                          </div>
                          <div className="font-medium">contact@secourspro.ma</div>
                        </div>
                      </a>
                    </div>

                    <Separator className="my-6" />

                    <h4 className="font-medium text-foreground mb-3">
                      Prochaines sessions
                    </h4>
                    <div className="space-y-3">
                      {["15 Juin 2026", "22 Juin 2026", "29 Juin 2026"].map(
                        (date, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                          >
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-primary" />
                              <span className="text-sm">{date}</span>
                            </div>
                            <Badge
                              variant="outline"
                              className={
                                index === 0
                                  ? "border-primary text-primary"
                                  : ""
                              }
                            >
                              {index === 0 ? "Places disponibles" : "Complet"}
                            </Badge>
                          </div>
                        )
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Related Formations */}
        {relatedFormations.length > 0 && (
          <section className="py-16">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl font-bold text-foreground mb-8">
                Formations similaires
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {relatedFormations.map((relatedFormation) => (
                  <Link
                    key={relatedFormation.id}
                    href={`/formations/${relatedFormation.id}`}
                  >
                    <Card className="h-full hover:border-primary/50 hover:shadow-lg transition-all group">
                      <div className="relative h-40 overflow-hidden rounded-t-lg">
                        <Image
                          src={relatedFormation.image}
                          alt={relatedFormation.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                          {relatedFormation.title}
                        </h3>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-primary font-bold">
                            {formatPrice(relatedFormation.price)}
                          </span>
                          <Badge variant="outline">
                            {relatedFormation.duration}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA Section */}
        <section className="py-16 bg-primary">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-primary-foreground mb-4">
              Prêt à vous former aux gestes qui sauvent ?
            </h2>
            <p className="text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
              Rejoignez les milliers de personnes qui ont déjà suivi nos
              formations et qui sont maintenant capables de sauver des vies.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-card text-primary hover:bg-card/90"
              >
                Réserver cette formation
              </Button>
              <Link href="/#contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
                >
                  Demander un devis entreprise
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default function FormationDetailPage() {
  const params = useParams();
  const formation = formations.find((f) => f.id === params.id);

  if (!formation) {
    return (
      <>
        <Header />
        <main className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Formation non trouvée
            </h1>
            <p className="text-muted-foreground mb-6">
              La formation que vous recherchez n&apos;existe pas ou a été supprimée.
            </p>
            <Link href="/#formations">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voir toutes les formations
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return <FormationDetailContent formation={formation} />;
}
